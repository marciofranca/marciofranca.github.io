<br>
<hr width="85%">
<br>
<p Align=CENTER><img src="images/bwf.gif" align="middle"><?echo $version; ?> - <? echo $date_lastmod; ?>

</body>
</html>
